import { ShieldCheck, HardDrive, Wifi, Database, Check } from 'lucide-react';

export default function SidebarInfo() {
  const items = [
    { icon: <ShieldCheck size={20} />, label: "Privacy & Security:", sub: "Secure, 0 Threats" },
    { icon: <HardDrive size={20} />, label: "Storage:", sub: "0.1 MB Used" },
    { icon: <Wifi size={20} />, label: "Network Activity:", sub: "Minimal, 0 Requests" },
    { icon: <Database size={20} />, label: "Data Transfer:", sub: "None" },
  ];

  return (
    <div className="w-80 flex flex-col justify-center gap-8 pr-8 border-r border-white/5">
      {items.map((item, i) => (
        <div key={i} className="flex items-start justify-between group cursor-default">
          <div className="flex gap-4">
            <div className="text-slate-400 group-hover:text-white transition-colors">
              {item.icon}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-slate-200">{item.label}</span>
              <span className="text-xs text-slate-500">{item.sub}</span>
            </div>
          </div>
          <Check size={18} className="text-slate-400 mt-1" />
        </div>
      ))}
    </div>
  );
}

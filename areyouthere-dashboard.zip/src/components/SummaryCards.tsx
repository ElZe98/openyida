import { User, LogOut, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';
import type { ReactNode } from 'react';

interface CardProps {
  icon: ReactNode;
  label: string;
  value: string;
  colorClass: string;
  isActive?: boolean;
}

function Card({ icon, label, value, colorClass, isActive }: CardProps) {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className={`flex-1 glass-card p-6 flex flex-col items-center justify-center gap-2 transition-all duration-300 ${isActive ? 'ring-1 ring-white/20 bg-white/5' : 'opacity-80'}`}
    >
      <div className="flex items-center gap-2 text-slate-300">
        {icon}
        <span className="text-lg font-medium">{label}</span>
      </div>
      <div className={`text-2xl font-mono font-medium ${colorClass}`}>
        {value}
      </div>
    </motion.div>
  );
}

export default function SummaryCards() {
  return (
    <div className="flex gap-4 px-8 py-4">
      <Card 
        icon={<User size={20} />}
        label="Present"
        value="0h 45m"
        colorClass="text-emerald-400"
        isActive={true}
      />
      <Card 
        icon={<LogOut size={20} />}
        label="Away"
        value="1h 20m"
        colorClass="text-orange-400"
      />
      <Card 
        icon={<HelpCircle size={20} />}
        label="Unknown"
        value="0m"
        colorClass="text-slate-500"
      />
    </div>
  );
}

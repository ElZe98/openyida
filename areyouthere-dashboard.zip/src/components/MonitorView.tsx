import { motion } from 'motion/react';

export default function MonitorView() {
  return (
    <div className="flex-1 glass-card p-6 flex gap-8 items-center">
      <div className="relative w-2/3 aspect-video rounded-lg overflow-hidden border border-white/10">
        <img 
          src="https://picsum.photos/seed/workspace/800/450" 
          alt="Monitor View"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover grayscale-[0.2] contrast-[1.1]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
      </div>
      
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-full bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.5)]" />
          <span className="text-4xl font-medium tracking-tight">Away</span>
        </div>
        
        <div className="space-y-2 mt-4">
          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-widest text-slate-500 font-mono">Confidence:</span>
            <span className="text-2xl font-mono">98%</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-widest text-slate-500 font-mono">Time:</span>
            <span className="text-2xl font-mono">09:53:36</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-widest text-slate-500 font-mono">AI Model:</span>
            <span className="text-xl font-mono text-slate-300">gemma4:e2b</span>
          </div>
        </div>
      </div>
    </div>
  );
}

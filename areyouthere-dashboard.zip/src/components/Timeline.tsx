import { motion } from 'motion/react';

export default function Timeline() {
  const hours = ['00:00', '04:00', '06:00', '12:00', '18:00', '20:00', '24:00'];
  
  return (
    <div className="w-full px-8 py-6">
      <div className="relative h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: '35%' }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-slate-400 to-white"
        />
        <div className="absolute top-0 left-[35%] h-full w-[65%] bg-gradient-to-r from-orange-400/50 to-orange-400/10" />
      </div>
      
      <div className="relative w-full mt-4 flex justify-between">
        {hours.map((hour, i) => (
          <div key={hour} className="flex flex-col items-center">
            <div className="h-2 w-px bg-slate-700 mb-1" />
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{hour}</span>
          </div>
        ))}
        
        {/* Sub-markers */}
        <div className="absolute top-0 left-0 w-full flex justify-between px-[2%] pointer-events-none opacity-30">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="h-1 w-px bg-slate-600" />
          ))}
        </div>
      </div>
    </div>
  );
}

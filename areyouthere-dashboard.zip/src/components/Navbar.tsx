import { Home, Activity, Settings, User } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between px-8 py-4 bg-transparent">
      <div className="flex items-center gap-2">
        {/* Placeholder for logo if needed */}
      </div>
      <div className="flex items-center gap-8 text-sm font-medium text-slate-400">
        <button className="flex items-center gap-2 text-white hover:text-white transition-colors">
          <Home size={18} />
          <span>Home</span>
        </button>
        <button className="flex items-center gap-2 hover:text-white transition-colors">
          <Activity size={18} />
          <span>Activity</span>
        </button>
        <button className="flex items-center gap-2 hover:text-white transition-colors">
          <Settings size={18} />
          <span>Settings</span>
        </button>
        <button className="flex items-center gap-2 hover:text-white transition-colors">
          <User size={18} />
          <span>Profile</span>
        </button>
      </div>
    </nav>
  );
}

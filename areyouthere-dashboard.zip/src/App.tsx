/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Timeline from './components/Timeline';
import SummaryCards from './components/SummaryCards';
import SidebarInfo from './components/SidebarInfo';
import MonitorView from './components/MonitorView';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="min-h-screen bg-dashboard-bg flex flex-col">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto w-full flex flex-col py-8 px-4">
        {/* Header Section */}
        <header className="text-center mb-8">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-light tracking-tight text-slate-400"
          >
            <span className="font-semibold text-white">AreYouThere</span> Desktop Dashboard
          </motion.h1>
        </header>

        {/* Timeline Section */}
        <section className="mb-4">
          <Timeline />
        </section>

        {/* Summary Cards Section */}
        <section className="mb-8">
          <SummaryCards />
        </section>

        {/* Main Content Grid */}
        <section className="flex gap-8 px-8 flex-1 items-stretch">
          <SidebarInfo />
          <MonitorView />
        </section>
      </main>

      {/* Footer / Status Bar */}
      <footer className="px-8 py-4 border-t border-white/5 flex justify-between items-center text-[10px] uppercase tracking-[0.2em] text-slate-600 font-mono">
        <div>System Status: Operational</div>
        <div>Last Sync: 2026-04-09 03:55:52 UTC</div>
      </footer>
    </div>
  );
}

